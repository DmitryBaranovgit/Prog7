from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from typing import Optional
from collections import Counter
from fastapi import Depends
from sqlalchemy.orm import Session
from database import get_db, BookDB
from auth import verify_api_key

app = FastAPI(
    title="Books API",
    description="REST API for managing a book library",
    version="1.0.0"
)

class Book(BaseModel):
    id: Optional[int] = None
    title: str = Field(..., min_length=1, max_length=200, description="Book title")
    author: str = Field(..., min_length=1, max_length=100, description="Book author")
    year: int = Field(..., ge=1000, le=datetime.now().year, description="Publication year")
    isbn: Optional[str] = Field(None, min_length=10, max_length=13, description="Book ISBN")

    class Config:
        json_schema_extra = {
            "example": {
                "title": "The Master and Margarita",
                "author": "Mikhail Bulgakov",
                "year": 1967,
                "isbn": "9785170123456"
            }
        }

class BookUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=1, max_length=200)
    author: Optional[str] = Field(None, min_length=1, max_length=100)
    year: Optional[int] = Field(None, ge=1000, le=datetime.now().year)
    isbn: Optional[str] = Field(None, min_length=10, max_length=13)

books_db: List[Book] = [
    Book(id=1, title="War and Peace", author="Leo Tolstoy", year=1869, isbn="9785170987654"),
    Book(id=2, title="Crime and Punishment", author="Fyodor Dostoevsky", year=1866, isbn="9785170876543"),
    Book(id=3, title="Eugene Onegin", author="Alexander Pushkin", year=1833, isbn="9785170765432")
]
next_id = 4

@app.get("/", tags=["Root"])
async def root():
    return {"message": "Welcome to Books API!", "docs": "/docs", "redoc": "/redoc"}

@app.get("/api/books", response_model=List[Book], tags=["Books"])
async def get_books(db: Session = Depends(get_db)):
    books = db.query(BookDB).all()
    return books
# (
    # author: Optional[str] = None,
    # year_from: Optional[int] = None,
    # year_to: Optional[int] = None
    # skip: int = 0,
    # limit: int = 10,
    # author: Optional[str] = None
# ):
    # filtered_books = books_db

    # if author:
    #     filtered_books = [b for b in filtered_books if author.lower() in b.author.lower()]
    # if year_from:
    #     filtered_books = [b for b in filtered_books if b.year >= year_from]
    # if year_to:
    #     filtered_books = [b for b in filtered_books if b.year <= year_to]

    # return filtered_books[skip: skip + limit]

@app.get("/api/books/{book_id}", response_model=Book, tags=["Books"])
async def get_book(book_id: int):
    for book in books_db:
        if book.id == book_id:
            return book
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Book with ID {book_id} not found")

@app.post("/api/books", response_model=Book, status_code=status.HTTP_201_CREATED, tags=["Books"])
async def create_book(book: Book, db: Session = Depends(get_db), api_key: str = Depends(verify_api_key)):
    db_book = BookDB(**book.model_dump(exclude={"id"}))
    db.add(db_book)
    db.commit()
    db.refresh(db_book)
    return db_book
# (book: Book):
#     global next_id
#     book.id = next_id
#     next_id += 1
#     books_db.append(book)
#     return book

@app.put("/api/books/{book_id}", response_model=Book, tags=["Books"])
async def update_book(book_id: int, updated_book: Book):
    for index, book in enumerate(books_db):
        if book.id == book_id:
            updated_book.id = book_id
            books_db[index] = updated_book
            return updated_book
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Book with ID {book_id} not found")

@app.patch("/api/books/{book_id}", response_model=Book, tags=["Books"])
async def partial_update_book(book_id: int, book_update: BookUpdate):
    for book in books_db:
        if book.id == book_id:
            update_data = book_update.model_dump(exclude_unset=True)
            for field, value in update_data.items():
                setattr(book, field, value)
            return book
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Book with ID {book_id} not found")

@app.delete("/api/books/{book_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Books"])
async def delete_book(book_id: int):
    for index, book in enumerate(books_db):
        if book.id == book_id:
            books_db.pop(index)
            return
    raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Book with ID {book_id} not found")

@app.get("/api/books/stats", tags=["Statistics"])
async def get_statistics():
    total_books = len(books_db)
    authors = Counter(book.author for book in books_db)
    centuries = Counter(book.year // 100 + 1 for book in books_db)

    return {
        "total_books": total_books,
        "books_by_author": dict(authors),
        "books_by_century": {f"{century} century": count for century, count in centuries.items()}
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)