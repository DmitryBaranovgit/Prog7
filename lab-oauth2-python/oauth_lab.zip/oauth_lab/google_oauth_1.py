import os
#import json
from requests_oauthlib import OAuth2Session
from dotenv import load_dotenv

load_dotenv()

CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
REDIRECT_URI = "http://localhost:8000/callback"

os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

SCOPE = ["openid", "email", "profile"]
AUTHORIZATION_BASE_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"

# TOKEN_FILE = "token.json"

# def save_token(token_dict):

oauth = OAuth2Session(CLIENT_ID, redirect_uri=REDIRECT_URI, scope=SCOPE)

authorization_url, state = oauth.authorization_url(AUTHORIZATION_BASE_URL, access_type="offline", prompt="consent")

print("Go to the link for authorization:")
print(authorization_url)

redirect_response = input("\nPaste the full redirect URL: ")

token = oauth.fetch_token(
    TOKEN_URL,
    authorization_response=redirect_response,
    client_secret=CLIENT_SECRET
)

print("\nYour token:")
print(token)

userinfo_endpoint = "https://www.googleapis.com/oauth2/v3/userinfo"
r = oauth.get(userinfo_endpoint)
print("\nUser information:")
print(r.json())