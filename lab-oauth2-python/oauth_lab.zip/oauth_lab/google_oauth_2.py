import os
import json
from requests_oauthlib import OAuth2Session
from dotenv import load_dotenv

load_dotenv()

CLIENT_ID = os.getenv("CLIENT_ID")
CLIENT_SECRET = os.getenv("CLIENT_SECRET")
REDIRECT_URI = "http://localhost:8000/callback"

os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

SCOPE = ["openid", "email", "profile"]
AUTHORIZATION_BASE_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"

TOKEN_FILE = "token.json"

def save_token(token_dict):
    with open(TOKEN_FILE, "w") as f:
        json.dump(token_dict, f)

def load_token():
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE, "r") as f:
            return json.load(f)
    return None

def refresh_token(old_token):
    data = {
        "grant_type": "refresh_token",
        "refresh_token": old_token["refresh_token"],
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET
    }
    import requests
    resp = requests.post(TOKEN_URL, data=data)
    resp.raise_for_status()
    new_tokens = resp.json()
    
    old_token.update({
        "access_token": new_tokens["access_token"],
        "expires_in": new_tokens.get("expires_in"),
        "scope": new_tokens.get("scope"),
        "token_type": new_tokens.get("token_type"),
    })
    save_token(old_token)
    return old_token

def obtain_new_token():
    oauth = OAuth2Session(CLIENT_ID, redirect_uri=REDIRECT_URI, scope=SCOPE)
    authorization_url, state = oauth.authorization_url(
        AUTHORIZATION_BASE_URL,
        access_type="offline",
        prompt="consent"
    )

    print("Go to the link for authorization:")
    print(authorization_url)
    redirect_response = input("\nPaste the full redirect URL: ")
    token = oauth.fetch_token(
        TOKEN_URL,
        authorization_response=redirect_response,
        client_secret=CLIENT_SECRET
    )
    save_token(token)
    return token

def main():
    token = load_token()
    if token:
        if "refresh_token" in token:
            print("Existing token found, refreshing ...")
            token = refresh_token(token)
        else:
            print("Token found but no refresh_token - obtaining new token ...")
            token = obtain_new_token()
    else:
        print("No token found - obtaining new token ...")
        token = obtain_new_token()

    print("\nYour token:")
    print(token)

    oauth = OAuth2Session(CLIENT_ID, token=token)
    userinfo_endpoint = "https://www.googleapis.com/oauth2/v3/userinfo"
    r = oauth.get(userinfo_endpoint)
    print("\nUser information:")
    print(r.json())

if __name__ == "__main__":
    main()