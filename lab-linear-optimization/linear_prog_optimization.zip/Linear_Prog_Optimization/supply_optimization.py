import numpy as np
from scipy.optimize import linprog
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

c = [8, 6, 10, 9, 7, 5]

A_eq = [
    [1, 1, 1, 0, 0, 0],
    [0, 0, 0, 1, 1, 1],
    [1, 0, 0, 1, 0, 0],
    [0, 1, 0, 0, 1, 0],
    [0, 0, 1, 0, 0, 1]
]

b_eq = [150, 250, 120, 180, 100]

bounds = [(0, None)] * 6

result = linprog(c, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method='highs')

print("=== Transportation Supply Problem ===")
print(f"Status: {result.message}")
x = result.x
print(f"x11 = {x[0]:.2f} tons")
print(f"x12 = {x[1]:.2f} tons")
print(f"x13 = {x[2]:.2f} tons")
print(f"x21 = {x[3]:.2f} tons")
print(f"x22 = {x[4]:.2f} tons")
print(f"x23 = {x[5]:.2f} tons")
print(f"Minimum total transportation cost: {result.fun:.2f} conv. units")

fig, ax = plt.subplots(figsize=(14, 10))

warehouses = {'Warehouse 1': (2, 8), 'Warehouse 2': (2, 3)}
bases = {'Alpha': (10, 10), 'Beta': (10, 5.5), 'Gamma': (10, 1)}

for name, (x, y) in warehouses.items():
    ax.add_patch(FancyBboxPatch((x-1, y-0.5), 2, 1, boxstyle="round,pad=0.1", fc="#AED6F1", ec="black"))
    ax.text(x, y, name, ha="center", va="center", fontsize=12, weight='bold')

for name, (x, y) in bases.items():
    ax.add_patch(FancyBboxPatch((x-1, y-0.5), 2, 1, boxstyle="round,pad=0.1", fc="#F9E79F", ec="black"))
    ax.text(x, y, "Base " + name, ha="center", va="center", fontsize=12, weight='bold')

flows = [
    ('Warehouse 1', 'Beta', 150, 6),
    ('Warehouse 2', 'Alpha', 120, 9),
    ('Warehouse 2', 'Beta', 30, 7),
    ('Warehouse 2', 'Gamma', 100, 5)
]

for wh, base, qty, cost in flows:
    if qty > 0:
        x1, y1 = warehouses[wh]
        x2, y2 = bases[base]
        arrow = FancyArrowPatch((x1 + 1, y1), (x2 - 1, y2),
                                arrowstyle='->', color='green',
                                linewidth=2 + qty / 60, alpha=0.7)
        ax.add_patch(arrow)
        ax.text((x1 + x2)/2, (y1 + y2)/2 + 0.3, f"{qty:.0f}t\n({cost})",
                ha="center", fontsize=10, color="darkgreen")

ax.set_xlim(0, 12)
ax.set_ylim(0, 12)
ax.set_aspect('equal')
ax.axis('off')
ax.set_title('Optimal Supply Plan', fontsize=16, fontweight='bold')
plt.tight_layout()
plt.show()