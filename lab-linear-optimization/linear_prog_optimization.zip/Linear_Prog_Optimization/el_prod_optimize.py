import numpy as np
from scipy.optimize import linprog
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

c = [-8000, -12000]

A_ub = [
    [2, 3],
    [4, 6],
    [1, 2]
]

b_ub = [240, 480, 150]

bounds = [(0, None), (0, None)]

result = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds, method='highs')

print("=== Electronics Production Optimization Task ===")
print(f"Status: {result.message}")
print(f"x1 (smartphones): {result.x[0]:.2f}")
print(f"x2 (tablets): {result.x[1]:.2f}")
print(f"Maximum profit: {-result.fun:.2f}")

fig, ax = plt.subplots(figsize=(10, 8))

x1 = np.linspace(0, 150, 400)

x2_constraint1 = (240 - 2 * x1) / 3
x2_constraint2 = (480 - 4 * x1) / 6
x2_constraint3 = (150 - 1 * x1) / 2

ax.plot(x1, x2_constraint1, label='Processor time', color='r')
ax.plot(x1, x2_constraint2, label='RAM memory', color='g')
ax.plot(x1, x2_constraint3, label='Batteries', color='b')

ax.set_xlim(0, 150)
ax.set_ylim(0, 120)

vertices = np.array([
    [0, 0],
    [0, 75],
    [30, 60],
    [120, 0]
])
polygon = Polygon(vertices, color='lightgray', alpha=0.4, label='Feasible region')
ax.add_patch(polygon)

x1_opt, x2_opt = result.x
ax.scatter(x1_opt, x2_opt, color='black', zorder=5, label='Optimal solution')
ax.text(x1_opt + 2, x2_opt, f"({x1_opt:.0f}, {x2_opt:.0f})", fontsize=10)

profit_levels = [400000, 600000, 800000, 960000]
for P in profit_levels:
    x2_line = (P - 8000 * x1) / 12000
    ax.plot(x1, x2_line, linestyle='--', color='gray', alpha=0.5)

ax.set_xlabel('x1 (smartphones)', fontsize=12)
ax.set_ylabel('x2 (tablets)', fontsize=12)
ax.set_title('Production Optimization: Geometric representation', fontsize=14)
ax.legend()
ax.grid(True, alpha=0.3)
plt.show()