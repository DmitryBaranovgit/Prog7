from django import forms
from .models import Question

class QuestionForm(forms.Form):
    question_text = forms.CharField(
        label='Question text',
        max_length=200,
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
    choices = forms.CharField(
        label='Answer options (one per line)',
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 5})
    )