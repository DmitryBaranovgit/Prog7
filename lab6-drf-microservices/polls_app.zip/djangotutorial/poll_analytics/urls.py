from django.urls import path
from .views import (QuestionStatsAPIView, QuestionFilterAPIView, QuestionChartAPIView, QuestionExportAPIView)

urlpatterns = [
    path('question/<int:pk>/stats/', QuestionStatsAPIView.as_view(), name='question-stats'),
    path('questions/filter/', QuestionFilterAPIView.as_view(), name='question-filter'),
    path('question/<int:pk>/chart/', QuestionChartAPIView.as_view(), name='question-chart'),
    path('questions/export/', QuestionExportAPIView.as_view(), name='question-export'),
]