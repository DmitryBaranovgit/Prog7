from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from polls.models import Question, Choice
from django.db.models import Sum
from django.utils import timezone

import plotly.graph_objects as go
import plotly.io as pio
import base64
from io import BytesIO

import csv
from django.http import HttpResponse

class QuestionStatsAPIView(APIView):
    def get(self, request, pk):
        try:
            question = Question.objects.get(pk=pk)
        except Question.DoesNotExist:
            return Response(
                {"error": "Question not found"},
                status=status.HTTP_404_NOT_FOUND
            )
        
        choices = question.choice_set.all()

        total_votes = choices.aggregate(Sum('votes'))['votes__sum'] or 0

        results = []
        for choice in choices:
            percent = (choice.votes / total_votes * 100) if total_votes > 0 else 0
            results.append({
                "choice_text": choice.choice_text,
                "votes": choice.votes,
                "percentage": round(percent, 2)
            })
        
        data = {
            "question_id": question.id,
            "question_text": question.question_text,
            "total_votes": total_votes,
            "results": results
        }

        return Response(data)

class QuestionFilterAPIView(APIView):
    def get(self, request):
        sort_by = request.GET.get('sort_by', 'date')
        from_date = request.GET.get('from', None)
        to_date = request.GET.get('to', None)

        questions = Question.objects.all()

        if from_date and to_date:
            try:
                from_dt = timezone.datetime.strptime(from_date, '%Y-%m-%d')
                to_dt = timezone.datetime.strptime(to_date, '%Y-%m-%d')
                questions = questions.filter(pub_date__range=[from_dt, to_dt])
            except ValueError:
                return Response(
                    {"error": "Invalid date format. Use YYYY-MM-DD"},
                    status=status.HTTP_400_BAD_REQUEST
                )
        
        if sort_by in ('votes', 'popularity'):
            questions = questions.annotate(total_votes=Sum('choice__votes')).order_by('-total_votes')
        elif sort_by == 'date':
            questions = questions.order_by('-pub_date')
        else:
            return Response(
                {"error": "Invalid sort_by parameter. Use 'date', 'votes' or 'popularity'"},
                status=status.HTTP_400_BAD_REQUEST
            )

        result = []
        for q in questions:
            total_votes = q.choice_set.aggregate(Sum('votes'))['votes__sum'] or 0
            result.append({
                "id": q.id,
                "question_text": q.question_text,
                "pub_date": q.pub_date,
                "total_votes": total_votes
            })
        
        return Response({"questions": result})

class QuestionChartAPIView(APIView):
    def get(self, request, pk):
        try:
            question = Question.objects.get(pk=pk)
        except Question.DoesNotExist:
            return Response(
                {"error": "Question not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        choices = question.choice_set.all()
        total_votes = choices.aggregate(Sum('votes'))['votes__sum'] or 0

        labels = [c.choice_text for c in choices]
        votes = [c.votes for c in choices]
        percentages = [
            round((c.votes / total_votes * 100), 2) if total_votes > 0 else 0
            for c in choices
        ]

        fig = go.Figure(data=[
            go.Bar(x=labels, y=percentages, text=percentages, textposition='auto')
        ])
        fig.update_layout(
            title=f"Voting results: {question.question_text}",
            xaxis_title="Answer choices",
            yaxis_title="Vote percentage (%)",
            template="plotly_white"
        )

        svg_bytes = pio.to_image(fig, format="svg")
        svg_str = svg_bytes.decode('utf-8')

        return Response({
            "question": question.question_text,
            "total_votes": total_votes,
            "labels": labels,
            "percentages": percentages,
            "chart_svg": svg_str
        })

class QuestionExportAPIView(APIView):
    def get(self, request):
        export_format = request.GET.get('format', 'json').lower()
        questions = Question.objects.all().prefetch_related('choice_set')

        if export_format == 'json':
            data = []
            for q in questions:
                choices = [
                    {"choice_text": c.choice_text, "votes": c.votes}
                    for c in q.choice_set.all()
                ]
                data.append({
                    "id": q.id,
                    "question_text": q.question_text,
                    "pub_date": q.pub_date,
                    "choices": choices
                })
            return Response({"questions": data})
        
        elif export_format == 'csv':
            response = HttpResponse(content_type='text/csv')
            response['Content-Disposition'] = 'attachment; filename="polls_export.csv"'

            writer = csv.writer(response)
            writer.writerow(['Question ID', 'Question Text', 'Choice', 'Votes', 'Publication Date'])

            for q in questions:
                for c in q.choice_set.all():
                    writer.writerow([q.id, q.question_text, c.choice_text, c.votes, q.pub_date])

            return response
        
        else:
            return Response(
                {"error": "Invalid format. Use ?format=json or ?format=csv"},
                status=status.HTTP_400_BAD_REQUEST
            )