from django.urls import path
from django.shortcuts import render

from . import views

app_name = "polls"
urlpatterns = [
    path("", views.IndexView.as_view(), name="index"),
    path("create/", views.create_poll, name="create_poll"),
    path("<int:pk>/", views.DetailView.as_view(), name="detail"),
    path("<int:pk>/results/", views.ResultsView.as_view(), name="results"),
    path("<int:question_id>/vote/", views.vote, name="vote"),
]

def search_polls_view(request):
    return render(request, 'polls/search_polls.html')

urlpatterns += [
    path('search/', search_polls_view, name='search-polls'),
]